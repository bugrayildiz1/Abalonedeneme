package finalProject.Exceptions;

public class NotValidPlayerException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NotValidPlayerException(String msg) {
		super(msg);	
	}
}
